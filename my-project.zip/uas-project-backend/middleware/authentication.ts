import type { NextFunction, Request, Response } from "express";
import { prisma } from "../lib/prisma";

export async function loggedIn(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const userId = Number(req.headers["x-user-id"]);

    if (!Number.isInteger(userId) || userId <= 0) {
      res.status(401).json({ message: "Login sebagai admin diperlukan." });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { user_id: userId },
    });

    if (!user) {
      res
        .status(403)
        .json({ message: "Tolong login!" });
      return;
    }

    next();
  } catch (error) {
    console.error("Error loggedIn:", error);
    res.status(500).json({ message: "Belum login!" });
  }
}
